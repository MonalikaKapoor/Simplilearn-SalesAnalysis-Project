# Sales Analysis Report
Dataset: AusApparalSales4thQrt2020.csv

## Detected Columns
- Date Column: Date
- Sales Column: Sales
- Units Column: Unit
- State Column: State
- Group Column: Group

## Top States by Sales
| State   |       Sales |
|:--------|------------:|
| VIC     | 1.05565e+08 |
| NSW     | 7.497e+07   |
| SA      | 5.88575e+07 |
| QLD     | 3.34175e+07 |
| TAS     | 2.276e+07   |

## Top Groups by Sales
| Group   |       Sales |
|:--------|------------:|
| Men     | 8.575e+07   |
| Women   | 8.54425e+07 |
| Kids    | 8.50725e+07 |
| Seniors | 8.40375e+07 |

